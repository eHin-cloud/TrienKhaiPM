<?php
/**
 * ============================================================
 * CẤU HÌNH API KEY CHO GOOGLE GEMINI AI
 * ============================================================
 * 
 * File này chứa API Key để kết nối với dịch vụ Google Gemini AI.
 * API Key được sử dụng bởi chức năng Trợ lý AI PRO (AI Chat)
 * trong footer.php để tư vấn sản phẩm cho khách hàng.
 * 
 * LƯU Ý BẢO MẬT:
 * - Không nên commit file này lên repository công khai.
 * - Nên đưa vào .gitignore hoặc sử dụng biến môi trường (env).
 * - Thay đổi API Key nếu bị lộ ra ngoài.
 * 
 * @see footer.php - Nơi sử dụng biến $GEMINI_API_KEY
 */
$GEMINI_API_KEY = "AIzaSyDxLs_QcSyy4952IeUVNzH2weAq0BTlvE8";

?>